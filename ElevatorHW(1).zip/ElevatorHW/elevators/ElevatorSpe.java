/*
 * @Description: 特殊电梯类
 * @Version: 
 * @Autor: Zhangchunhao
 * @Date: 2022-04-25 13:41:08
 * @LastEditors: Zhanchunhao
 * @LastEditTime: 2022-04-25 20:13:20
 */
package elevators;

public class ElevatorSpe extends IElevator {

    public ElevatorSpe(int id, int curflr) {
        super(id, curflr, 10, 800);
    }

    @Override
    public void riseCurflr() {
        curflr += 2;
    }

    @Override
    public void decCurflr() {
        curflr -= 2;
    }

}
