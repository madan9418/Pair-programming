/*
 * @Description: 普通电梯类
 * @Version: 
 * @Autor: Zhangchunhao
 * @Date: 2022-04-25 13:37:34
 * @LastEditors: Zhanchunhao
 * @LastEditTime: 2022-04-25 20:06:44
 */
package elevators;

public class ElevatorCom extends IElevator {

    public ElevatorCom(int id, int carrypeoplenum, int carrycargo) {
        super(id, 1, carrypeoplenum, carrycargo);
    }

    @Override
    public void riseCurflr() {
        curflr++;
    }

    @Override
    public void decCurflr() {
        curflr--;
    }

}
