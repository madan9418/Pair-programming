package elevators;

/*
 * @Description: 电梯类
 * @Version: 
 * @Autor: Zhangchunhao
 * @Date: 2022-04-25 13:18:50
 * @LastEditors: Zhanchunhao
 * @LastEditTime: 2022-04-25 20:13:22
 */
public abstract class IElevator {
    int id;// 电梯号
    int curflr;// 电梯当前所在层数
    int carrypeoplenum;// 载客量
    int carrycargo;// 载物量
    boolean busy;// 忙碌状态

    public int getId() {
        return id;
    }

    public int getCarrycargo() {
        return carrycargo;
    }

    public IElevator(int id, int curflr, int carrypeoplenum, int carrycargo) {
        this.id = id;
        this.curflr = curflr;
        this.carrypeoplenum = carrypeoplenum;
        this.carrycargo = carrycargo;
        this.busy = false;
    }

    public abstract void riseCurflr();

    public abstract void decCurflr();

    public int getCurflr() {
        return curflr;
    }

    public int getCarryPeopleNum() {
        return carrypeoplenum;
    }

    public boolean isBusy() {
        return busy;
    }

    public void setBusy(boolean busy) {
        this.busy = busy;
    }

}
