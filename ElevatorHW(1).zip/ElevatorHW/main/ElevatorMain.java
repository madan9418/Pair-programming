/*
 * @Description: 
 * @Version: 
 * @Autor: Zhangchunhao
 * @Date: 522-04-25 16:50:13
 * @LastEditors: Zhanchunhao
 * @LastEditTime: 2022-04-28 14:55:07
 */
package main;

import Threads.Supervisor;
import Threads.ThreadPool;
import Threads.Worker;
import swing.SwingView;

public class ElevatorMain {
    public static void main(String args[]) {
        Supervisor Sv = new Supervisor("Supervisor");
        // 创建监督线程
        Worker wk1 = new Worker("wk1");
        Worker wk2 = new Worker("wk2");
        Worker wk3 = new Worker("wk3");
        Worker wk4 = new Worker("wk4");
        // 创建工作线程
        ThreadPool.addThread(wk1);
        ThreadPool.addThread(wk2);
        ThreadPool.addThread(wk3);
        ThreadPool.addThread(wk4);
        // 工作线程放入线程池
        Sv.start();
        // 运行监督线程
        try {
            SwingView.displaySwing();
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
