package main;

import Request.Request;
import Request.RequestPool;
import elevators.ElevatorCom;
import elevators.ElevatorSpe;
import elevators.IElevator;

/*
 * @Description: 
 * @Version: 
 * @Autor: Zhangchunhao
 * @Date: 2022-04-25 14:56:30
 * @LastEditors: Zhanchunhao
 * @LastEditTime: 2022-04-25 21:17:50
 */
public class RequestHandle {
    static public ElevatorCom elevator1 = new ElevatorCom(1, 10, 800);
    static public ElevatorCom elevator4 = new ElevatorCom(4, 20, 2000);
    static public ElevatorSpe elevator2 = new ElevatorSpe(2, 1);
    static public ElevatorSpe elevator3 = new ElevatorSpe(3, 0);
    // 四个电梯实体
    static private Integer signal = 1;

    // 一个信号量
    /**选择电梯
     * @description: 
     * @param {*}
     * @return {*}
     * @author: Zhangchunhao
     */    
    static public void Handle() throws InterruptedException {
        Request request = null;
        while (true) {
            synchronized (signal) {
                // 对信号量加同步锁，以实现线程互斥访问（但实际用似乎没效果，多个线程依然可以同时访问）
                if (signal == 1) {
                    signal--;

                }
                request = RequestPool.getRequest();// 从请求池获取一个请求
                assert (request != null);
                signal++;
                break;
            }
        }

        int Rflr = request.getRequestflr();
        int Tflr = request.getTargetflr();

        // 以下是相当复杂恶心的电梯调度算法，而且还不是很正确，应该有改良空间
        if (request.getPeoplenum() > 10 || request.getCargo() > 800) {
            moveElevator(Rflr, Tflr, elevator4);
        } else if ((Rflr % 2) != (Tflr % 2)) {

            if (elevator1.isBusy() && elevator4.isBusy()) {
                while (true) {
                    if (!elevator1.isBusy() || !elevator4.isBusy())
                        break;
                    else
                        Thread.sleep(10);
                }
            }
            Boolean ele1 = elevator1.isBusy();
            Boolean ele4 = elevator4.isBusy();
            if (!ele1 && !ele4) {
                if (Math.abs(elevator1.getCurflr() - Rflr) > Math.abs(elevator4.getCurflr() - Rflr)) {
                    moveElevator(Rflr, Tflr, elevator4);
                } else
                    moveElevator(Rflr, Tflr, elevator1);
            } else if (!ele1) {
                moveElevator(Rflr, Tflr, elevator1);
            } else {
                moveElevator(Rflr, Tflr, elevator4);
            }
        } else if (Rflr % 2 == 0) {
            if (elevator1.isBusy() && elevator4.isBusy() && elevator3.isBusy()) {
                while (true) {
                    if (!elevator1.isBusy() || !elevator4.isBusy() || !elevator3.isBusy())
                        break;
                    else
                        Thread.sleep(10);
                }
            }
            Boolean ele1 = elevator1.isBusy();
            Boolean ele3 = elevator3.isBusy();
            Boolean ele4 = elevator4.isBusy();
            if (!ele1 && !ele4 && !ele3) {
                if (Math.abs(elevator1.getCurflr() - Rflr) > Math.abs(elevator4.getCurflr() - Rflr)) {
                    if (Math.abs(elevator3.getCurflr() - Rflr) > Math.abs(elevator4.getCurflr() - Rflr)) {
                        moveElevator(Rflr, Tflr, elevator4);
                    } else {
                        moveElevator(Rflr, Tflr, elevator3);
                    }
                } else if (Math.abs(elevator3.getCurflr() - Rflr) > Math.abs(elevator1.getCurflr() - Rflr)) {
                    moveElevator(Rflr, Tflr, elevator1);
                } else
                    moveElevator(Rflr, Tflr, elevator3);
            } else if (!ele3) {
                moveElevator(Rflr, Tflr, elevator3);
            } else if (!ele1) {
                moveElevator(Rflr, Tflr, elevator1);
            } else
                moveElevator(Rflr, Tflr, elevator4);
        } else {
            if (elevator1.isBusy() && elevator4.isBusy() && elevator2.isBusy()) {
                while (true) {
                    if (!elevator1.isBusy() || !elevator4.isBusy() || !elevator2.isBusy())
                        break;
                    else
                        Thread.sleep(10);
                }
            }
            Boolean ele1 = elevator1.isBusy();
            Boolean ele2 = elevator2.isBusy();
            Boolean ele4 = elevator4.isBusy();
            if (!ele1 && !ele4 && !ele2) {
                if (Math.abs(elevator1.getCurflr() - Rflr) > Math.abs(elevator4.getCurflr() - Rflr)) {
                    if (Math.abs(elevator2.getCurflr() - Rflr) > Math.abs(elevator4.getCurflr() - Rflr)) {
                        moveElevator(Rflr, Tflr, elevator4);
                    } else {
                        moveElevator(Rflr, Tflr, elevator2);
                    }
                } else if (Math.abs(elevator2.getCurflr() - Rflr) > Math.abs(elevator1.getCurflr() - Rflr)) {
                    moveElevator(Rflr, Tflr, elevator1);
                } else
                    moveElevator(Rflr, Tflr, elevator2);
            } else if (!ele2) {
                moveElevator(Rflr, Tflr, elevator2);
            } else if (!ele1) {
                moveElevator(Rflr, Tflr, elevator1);
            } else
                moveElevator(Rflr, Tflr, elevator4);
        }
    }
    /**
     * @description: 运行电梯
     * @param {int} Rflr
     * @param {int} Tflr
     * @param {IElevator} elevator
     * @return {*}
     * @author: Zhangchunhao
     */    
    static public void moveElevator(int Rflr, int Tflr, IElevator elevator) throws InterruptedException {

        while (true) {

            if (!elevator.isBusy()) {
                elevator.setBusy(true);
                break;
            }

        }
        System.out.println(elevator.getId() + "电梯开始");
        while (true) {
            Thread.sleep(1500);
            System.out.println(elevator.getId() + "电梯来到了" + elevator.getCurflr() + "层");
            if (Rflr > elevator.getCurflr()) {
                elevator.riseCurflr();
            } else if (Rflr < elevator.getCurflr()) {
                elevator.decCurflr();
            } else
                break;
        }

        while (true) {
            Thread.sleep(1500);
            System.out.println(elevator.getId() + "电梯来到了" + elevator.getCurflr() + "层");
            if (Tflr > elevator.getCurflr()) {
                elevator.riseCurflr();
            } else if (Tflr < elevator.getCurflr()) {
                elevator.decCurflr();
            } else
                break;
        }

        elevator.setBusy(false);

        System.out.println(elevator.getId() + "电梯结束" + Rflr + Tflr);
    }

}
