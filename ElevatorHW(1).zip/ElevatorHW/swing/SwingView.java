package swing;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import Request.Request;
import Request.RequestPool;
import main.RequestHandle;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SwingView {
    public static void displaySwing() throws InterruptedException {

        JFrame frame = new JFrame("电梯运行演示"); // 创建Frame窗口
        JPanel jp = new JPanel(); // 创建一个JPanel对象

        final JTextArea jta1 = new JTextArea("请输入当前层数", 4, 7);
        jta1.setLineWrap(true); // 设置文本域中的文本为自动换行
        jta1.setForeground(Color.BLACK); // 设置组件的背景色
        jta1.setFont(new Font("楷体", Font.BOLD, 16)); // 修改字体样式
        jta1.setBackground(Color.YELLOW); // 设置按钮背景色
        JScrollPane jsp1 = new JScrollPane(jta1); // 将文本域放入滚动窗口
        Dimension size1 = jta1.getPreferredSize(); // 获得文本域的首选大小
        jsp1.setBounds(110, 90, size1.width, size1.height);
        jp.add(jsp1); // 将JScrollPane添加到JPanel容器中
        // frame.add(jp); // 将JPanel容器添加到JFrame容器中

        final JTextArea jta2 = new JTextArea("请输入到达层数", 4, 7);
        jta2.setLineWrap(true); // 设置文本域中的文本为自动换行
        jta2.setForeground(Color.BLACK); // 设置组件的背景色
        jta2.setFont(new Font("楷体", Font.BOLD, 16)); // 修改字体样式
        jta2.setBackground(Color.YELLOW); // 设置按钮背景色
        JScrollPane jsp2 = new JScrollPane(jta2); // 将文本域放入滚动窗口
        Dimension size2 = jta2.getPreferredSize(); // 获得文本域的首选大小
        jsp2.setBounds(110, 90, size2.width, size2.height);
        jp.add(jsp2); // 将JScrollPane添加到JPanel容器中
        // frame.add(jp); // 将JPanel容器添加到JFrame容器中

        final JTextArea jta3 = new JTextArea("人数", 4, 7);
        jta3.setLineWrap(true); // 设置文本域中的文本为自动换行
        jta3.setForeground(Color.BLACK); // 设置组件的背景色
        jta3.setFont(new Font("楷体", Font.BOLD, 16)); // 修改字体样式
        jta3.setBackground(Color.YELLOW); // 设置按钮背景色
        JScrollPane jsp3 = new JScrollPane(jta3); // 将文本域放入滚动窗口
        Dimension size3 = jta3.getPreferredSize(); // 获得文本域的首选大小
        jsp3.setBounds(110, 90, size3.width, size3.height);
        jp.add(jsp3); // 将JScrollPane添加到JPanel容器中
        // frame.add(jp); // 将JPanel容器添加到JFrame容器中

        final JTextArea jta4 = new JTextArea("货物", 4, 7);
        jta4.setLineWrap(true); // 设置文本域中的文本为自动换行
        jta4.setForeground(Color.BLACK); // 设置组件的背景色
        jta4.setFont(new Font("楷体", Font.BOLD, 16)); // 修改字体样式
        jta4.setBackground(Color.YELLOW); // 设置按钮背景色
        JScrollPane jsp4 = new JScrollPane(jta4); // 将文本域放入滚动窗口
        Dimension size4 = jta4.getPreferredSize(); // 获得文本域的首选大小
        jsp4.setBounds(110, 90, size4.width, size4.height);
        jp.add(jsp4); // 将JScrollPane添加到JPanel容器中
        // frame.add(jp); // 将JPanel容器添加到JFrame容器中

        final JButton sendBtn = new JButton("发送");
        sendBtn.setBounds(100, 70, 80, 25);
        sendBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String msg1 = jta1.getText();
                String msg2 = jta2.getText();
                String msg3 = jta3.getText();
                String msg4 = jta4.getText();
                try {
                    SendMessage(msg1, msg2, msg3, msg4);
                } catch (Exception e1) {
                }
                System.out.println("已发送信息");
            }
        });
        jp.add(sendBtn);
        // frame.add(jp);

        final JTextArea Ap1 = new JTextArea("", 4, 7);
        final JTextArea Ap2 = new JTextArea("", 4, 7);
        final JTextArea Ap3 = new JTextArea("", 4, 7);
        final JTextArea Ap4 = new JTextArea("", 4, 7);

        Ap1.setText("电梯1所在层\n\n" + RequestHandle.elevator1.getCurflr());
        Ap2.setText("电梯2所在层\n\n" + RequestHandle.elevator2.getCurflr());
        Ap3.setText("电梯3所在层\n\n" + RequestHandle.elevator3.getCurflr());
        Ap4.setText("电梯4所在层\n\n" + RequestHandle.elevator4.getCurflr());

        Ap1.setLineWrap(true); // 设置文本域中的文本为自动换行
        Ap1.setForeground(Color.BLACK); // 设置组件的背景色
        Ap1.setFont(new Font("楷体", Font.BOLD, 16)); // 修改字体样式
        Ap1.setBackground(Color.RED); // 设置按钮背景色
        JScrollPane J1 = new JScrollPane(Ap1); // 将文本域放入滚动窗口
        Dimension se1 = Ap1.getPreferredSize(); // 获得文本域的首选大小
        J1.setBounds(210, 90, se1.width, se1.height);
        jp.add(Ap1); // 将JScrollPane添加到JPanel容器中

        Ap2.setLineWrap(true); // 设置文本域中的文本为自动换行
        Ap2.setForeground(Color.BLACK); // 设置组件的背景色
        Ap2.setFont(new Font("楷体", Font.BOLD, 16)); // 修改字体样式
        Ap2.setBackground(Color.RED); // 设置按钮背景色
        JScrollPane J2 = new JScrollPane(Ap2); // 将文本域放入滚动窗口
        Dimension se2 = Ap2.getPreferredSize(); // 获得文本域的首选大小
        J2.setBounds(210, 90, se2.width, se2.height);
        jp.add(Ap2); // 将JScrollPane添加到JPanel容器中

        Ap3.setLineWrap(true); // 设置文本域中的文本为自动换行
        Ap3.setForeground(Color.BLACK); // 设置组件的背景色
        Ap3.setFont(new Font("楷体", Font.BOLD, 16)); // 修改字体样式
        Ap3.setBackground(Color.RED); // 设置按钮背景色
        JScrollPane J3 = new JScrollPane(Ap3); // 将文本域放入滚动窗口
        Dimension se3 = Ap3.getPreferredSize(); // 获得文本域的首选大小
        J3.setBounds(210, 90, se3.width, se3.height);
        jp.add(Ap3); // 将JScrollPane添加到JPanel容器中

        Ap4.setLineWrap(true); // 设置文本域中的文本为自动换行
        Ap4.setForeground(Color.BLACK); // 设置组件的背景色
        Ap4.setFont(new Font("楷体", Font.BOLD, 16)); // 修改字体样式
        Ap4.setBackground(Color.RED); // 设置按钮背景色
        JScrollPane J4 = new JScrollPane(Ap4); // 将文本域放入滚动窗口
        Dimension se4 = Ap4.getPreferredSize(); // 获得文本域的首选大小
        J4.setBounds(210, 90, se4.width, se4.height);
        jp.add(Ap4); // 将JScrollPane添加到JPanel容器中

        frame.add(jp); // 将JPanel容器添加到JFrame容器中
        frame.setBackground(Color.LIGHT_GRAY);
        frame.setSize(450, 400); // 设置JFrame容器的大小
        frame.setVisible(true);

        while (true) {
            Thread.sleep(10);
            Ap1.setText("电梯1所在层\n\n" + RequestHandle.elevator1.getCurflr());
            Ap2.setText("电梯2所在层\n\n" + RequestHandle.elevator2.getCurflr());
            Ap3.setText("电梯3所在层\n\n" + RequestHandle.elevator3.getCurflr());
            Ap4.setText("电梯4所在层\n\n" + RequestHandle.elevator4.getCurflr());
        }
    }

    public static void SendMessage(String m1, String m2, String m3, String m4) {
        Request request = new Request(Integer.parseInt(m1), Integer.parseInt(m2), Integer.parseInt(m3),
                Integer.parseInt(m4));
        RequestPool.addRequest(request);
        try {
            Thread.sleep(300);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
