package Threads;
/*
 * @Description: 监督线程，监听请求队列，若有请求则唤醒一个工作进程worker
 * @Version: 
 * @Autor: Zhangchunhao
 * @Date: 2022-04-25 13:01:00
 * @LastEditors: Zhanchunhao
 * @LastEditTime: 2022-04-25 20:19:57
 */

import Request.RequestPool;

public class Supervisor implements Runnable {
   private Thread t;
   private String threadName;

   public Supervisor(String name) {
      threadName = name;
      System.out.println("Creating " + threadName);
   }

   public void run() {
      while (true) {
         if (!RequestPool.poolIsEmpty()) {
            Worker worker = ThreadPool.getSpareThread();
            //从线程池中获取一个工作线程
            if (worker != null) {
               worker.setBusy(true);
               worker.start();
               //工人开始工作
               try {
                  Thread.sleep(1200);
               } catch (InterruptedException e) {
                  // TODO Auto-generated catch block
                  e.printStackTrace();
               }
            }
         } else {
            try {
               Thread.sleep(10);//没事就睡觉，防止监督者死亡
            } catch (InterruptedException e) {
               // TODO Auto-generated catch block
               e.printStackTrace();
            }
         }
      }
   }

   public void start() {
      System.out.println("Starting " + threadName);
      if (t == null) {
         t = new Thread(this, threadName);
         t.start();
      }
   }
}
