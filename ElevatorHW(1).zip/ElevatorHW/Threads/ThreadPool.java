/*
 * @Description: 
 * @Version: 线程池，需要工作线程时取走一个，完成了工作的线程放回池中，等待下一次工作
 * @Autor: Zhangchunhao
 * @Date: 2022-04-25 14:01:19
 * @LastEditors: Zhanchunhao
 * @LastEditTime: 2022-04-25 20:22:03
 */
package Threads;

import java.util.ArrayList;
import java.util.List;

public class ThreadPool {
    static List<Worker> workerlist = new ArrayList<>();

    static public boolean addThread(Worker worker) {
        if (worker.isBusy())
            return false;
        workerlist.add(worker);
        return true;
    }

    static public Worker getSpareThread() {
        if (workerlist.isEmpty())
            return null;
        Worker worker = workerlist.get(0);
        workerlist.remove(0);
        return worker;
    }
}
