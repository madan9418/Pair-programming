/*
 * @Description: 工作线程
 * @Version: 
 * @Autor: Zhangchunhao
 * @Date: 2022-04-25 13:59:14
 * @LastEditors: Zhanchunhao
 * @LastEditTime: 2022-04-25 20:24:26
 */
package Threads;

import main.RequestHandle;

public class Worker implements Runnable {
   private Thread t;
   private String threadName;
   private boolean busy;// 工作线程忙碌状态

   public boolean isBusy() {
      return busy;
   }

   public void setBusy(boolean busy) {
      this.busy = busy;
   }

   public Worker(String name) {
      threadName = name;
      System.out.println("Creating " + threadName);
   }

   public void run() {
      try {
         RequestHandle.Handle();// 工人去处理请求
      } catch (InterruptedException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }
      busy = false;
      this.t = null;
      ThreadPool.addThread(this);// 工作完成的工人放回线程池

   }

   public void start() {
      System.out.println("Starting " + threadName);
      if (t == null) {
         t = new Thread(this, threadName);
         t.start();
      } else {
         t.start();
      }
   }
}
