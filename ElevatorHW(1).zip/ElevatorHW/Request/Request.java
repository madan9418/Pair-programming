/*
 * @Description: 请求体
 * @Version: 
 * @Autor: Zhangchunhao
 * @Date: 2022-04-25 14:26:07
 * @LastEditors: Zhanchunhao
 * @LastEditTime: 2022-04-25 20:13:57
 */
package Request;

public class Request {
    int requestflr;// 请求所在层数
    int targetflr;// 目标层数
    int peoplenum;// 人数
    int cargo;// 货物量

    public Request(int requestflr, int targetflr, int peoplenum, int cargo) {
        this.requestflr = requestflr;
        this.targetflr = targetflr;
        this.peoplenum = peoplenum;
        this.cargo = cargo;
    }

    public int getRequestflr() {
        return requestflr;
    }

    public int getTargetflr() {
        return targetflr;
    }

    public int getPeoplenum() {
        return peoplenum;
    }

    public int getCargo() {
        return cargo;
    }

}
