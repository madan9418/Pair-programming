/*
 * @Description: 请求队列，所有请求插入到请求队列里等待响应
 * @Version: 
 * @Autor: Zhangchunhao
 * @Date: 2022-04-25 14:23:03
 * @LastEditors: Zhanchunhao
 * @LastEditTime: 2022-04-25 20:16:59
 */
package Request;

import java.util.ArrayList;
import java.util.List;

public class RequestPool {
    static List<Request> requestlist = new ArrayList<>();

    static public void addRequest(Request request) {
        requestlist.add(request);
    }

    static public boolean poolIsEmpty() {
        return requestlist.isEmpty();
    }

    /**
     * @description: 弹出请求队列第一个请求
     * @param {*}
     * @return {Request}
     * @author: Zhangchunhao
     */
    static public Request getRequest() {
        if (requestlist.isEmpty())
            return null;
        Request request = requestlist.get(0);
        requestlist.remove(0);
        return request;
    }
}